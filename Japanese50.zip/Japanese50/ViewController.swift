//
//  ViewController.swift
//  Japanese50
//
//  Created by 林郁琦 on 2024/1/24.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    let synthesizer = AVSpeechSynthesizer()
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var clickButton: UIButton!
    
    @IBOutlet weak var rateSlider: UISlider!
    
    @IBOutlet weak var volumeSlider: UISlider!
    
    
    let speechText = [ "あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func speak(_ sender: UIButton) {
        
        let character = speechText[sender.tag]
        let speech = AVSpeechUtterance(string: character)
            speech.voice = AVSpeechSynthesisVoice(language: "ja-JP")
            speech.rate = rateSlider.value
            speech.volume = volumeSlider.value
            synthesizer.speak(speech)
        
        
    }
}
    
    
    


